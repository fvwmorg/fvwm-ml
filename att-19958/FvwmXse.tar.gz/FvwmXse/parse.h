/*
 * parse.h : Definitions for routines that parse strings into lists
 *	events.
 *
 * George Ferguson, ferguson@cs.rochester.edu, 1 Jun 1990.
 *
 * Version 1.6 - 5 Jan 1992.
 */

typedef struct eventListStruct {
	XEvent event;
	long count;
	struct eventListStruct *next;
} EventListElem,*EventListPtr;

extern char *parseEventList();
