/*
 * xse.h : Definitions for global graphics data, etc.
 *
 * George Ferguson, ferguson@cs.rochester.edu, 5 Jan 1992.
 *
 */

extern Display *display;
extern Window root;
