/*
 * FvwmXse - a Fvwm interface to XSendEvent()
 *
 * This Fvwm module is based heavily on the program Xse
 * written by George Ferguson.  Most of the information
 * here is taken from that program and is indepted to
 * the original program.
 *
 * History:
 *
 * Richard A. Guay, rag@asicint.com, 8 May 1997.
 *
 * Version 2.0 - 8 May 1997
 *     Changed the original program into an Fvwm module.
 *
 * George Ferguson, ferguson@cs.rochester.edu,  1 Jun 1990.
 *
 * Version 1.6 - 5 Jan 1992.
 *
 */
#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <string.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Cardinals.h>
#include "../../fvwm/module.h"
#include "../../libs/fvwmlib.h"
#include "parse.h"
#include "patchlevel.h"

/*      -       -       -       -       -       -       -       -       */
/*
 * Functions defined in this file
 */
static void initGraphics();
static void quit(),send(), done(int);
void DeadPipe(int);
static void parseAndSendEvents(), fail();
static Window windowFromString();
static Window GetRootWindow(), Window_With_Name(), Select_Window();

/*
 * Action binding table
 */
static XtActionsRec cmdActionsTable[] = {
    { "FvwmXse-quit", quit },
    { "FvwmXse-send", send },
};

/*
 * Global graphics data:
 */
Display *display;
Window root;

/*
 * Global widget data:
 */
static XtAppContext appContext;
static Widget toplevel;

/*
 * The application resources structure
 */
typedef struct {
        String window;
        String widgets;
        Boolean versionOnly;
} AppResources;
static AppResources appResources;

/*
 * Non-widget resources obtained from resource manager
 */
static XtResource resources[] = {
    { "widgets", "Widgets", XtRString, sizeof(String),
      XtOffset(AppResources *,widgets), XtRImmediate, (XtPointer)NULL },
    { "window", "Window", XtRString, sizeof(String),
      XtOffset(AppResources *,window), XtRImmediate,(XtPointer)"ClickWindow" },
    { "versionOnly", "VersionOnly", XtRBoolean, sizeof(Boolean),
      XtOffset(AppResources *,versionOnly), XtRImmediate, (XtPointer)False },
};

/*
 * Non-widget resources set on command line.
 */
static XrmOptionDescRec options[] = {
    { "-window",        "window",       XrmoptionSepArg,        "ClickWindow"},
    { "-version",       "versionOnly",  XrmoptionNoArg,         "True"},
};

/*
 * Widget and non-widget resources if the application defaults file can't
 * be found.
 * [ Generated automatically from FvwmXse.ad by "ad2c". ]
 */
static String fallbackResources[] = {
#include "FvwmXse.ad.h"
        NULL
};

/*
 * Global data.
 */
int fd[2];
int fd_width;

/*      -       -       -       -       -       -       -       -       */
/*
 * Routine:     main
 *
 * Description: This is the main routine.  All setup functions are performed here.
 *              The initialization of the Fvwm command pipes and the graphics information
 *              is done first.  Then the message processing loop is entered.  All
 *              messages are processed as recieved.  When the pipes die, then we exit.
 */
main(argc, argv)
int argc;
char **argv;
{
    Window              win;
    unsigned long       header[HEADER_SIZE], *body;
    int                 ret, bodysize;

    /*
     * Make sure the right number of arguments have been passed.
     * If less than six arguments have been given, then you can
     * assume that fvwm did not launch the program.
     */
    if (argc < 6) {
       fprintf(stderr,"Modules should only be executed by fvwm!\n");
       fprintf(stderr,"FvwmXse %d.%d%s -- Richard A. Guay, rag@asicint.com\n",
               FVWM_XSE_MAJOR_VERSION,FVWM_XSE_MINOR_VERSION,FVWM_XSE_EXTRA_VERSION);
       exit(1);
    }

    /*
     * Get the pipe descriptors for communicating with fvwm.
     */
    fd[0] = atoi(argv[1]);
    fd[1] = atoi(argv[2]);

    /*
     * Setup the signal processing.  If the pipe breaks, kill
     * the program.
     */
    signal (SIGPIPE, DeadPipe);

    /*
     * Send a NOP for a test.
     */
    SendText(fd,"Nop",0);

    /*
     * Tell fvwm what type of messages we want to recieve.
     */
    SetMessageMask(fd,M_STRING);

    /*
     * Initialize the graphics information
     */
    initGraphics();

    /*
     * This is the processing loop.  Here, we recieve commands
     * from fvwm and process the information.
     */
    while (1) {
       /*
        * Get a packet from fvwm.
        */

       ret = ReadFvwmPacket(fd[1],header,&body);
       bodysize = (header[2]-HEADER_SIZE)*sizeof(unsigned long);

       if (ret > 0) {
          /*
           * Make sure it is a M_String command before processing.
           */
          if (header[1] == M_STRING) {
             /*
              * It is a M_String command!  Process the command!
              */
             char *line, *msg;
             int  end, index;

             index = 0;

             /*
              * First, obtain the window identifier.
              */
             line = msg = (char *) &body[3];
             while ((*msg != '\0') && (*msg != ' ') && (index < bodysize)) {
                index++;
                msg++;
             }
             if ((*msg == '\0') || (index >= bodysize)) {
                end = 0;
             } else {
                end = 1;
                *msg = '\0';
                index++;
                msg++;
             }
             win = windowFromString(line);

             if (win != None) {
                /*
                 * Now, get the rest of the input and send it
                 * to that window.
                 */
                while (end) {
                   line = (char *) msg;
                   while ((*msg != '\0') && (*msg != ' ') && (index < bodysize)) {
                      index++;
                      msg++;
                   }
                   if ((*msg == '\0') || (index >= bodysize)) {
                      end = 0;
                   } else {
                      *msg = '\0';
                      index++;
                      msg++;
                   }
                   parseAndSendEvents(win,line);
                }
             }
          }
       } else {
          if (ret < 0) {
             /*
              * Pipe dead!
              */
             done(0);
          }
       }
       /*
        * Free up the body information and graphics
        */
       free(body);
    }

    /*
     *  We need to exit now.
     */
    done(0);
}

/***********************************************************************
 *
 *  Procedure:
 *      SIGPIPE handler - SIGPIPE means fvwm is dying
 *
 ***********************************************************************/
void DeadPipe(int num)
{
   done(0);
}

/***********************************************************************
 *
 *  Procedure:
 *      done - common exit point for FvwmAudio.
 *
 ***********************************************************************/
void    done(int n)
{
    XSynchronize(display,0);
    XtDestroyApplicationContext(appContext);
    exit(n);
}

/*
 * initGraphics() : Initialize the application context and set global
 *      graphics variables.
 */
/*initGraphics(argcp,argv)
int *argcp;
char **argv; */
static void
initGraphics()
{
    int *argc;
    char **argv;
    int num;

    argc = &num;
    num = 0;
    toplevel = XtAppInitialize(&appContext, "FvwmXse",
                               options, XtNumber(options),
                               argc,argv,fallbackResources,NULL,ZERO);
    display = XtDisplay(toplevel);
    root = GetRootWindow(display,DefaultScreen(display));
    XSynchronize(display,1);
}

/*      -       -       -       -       -       -       -       -       */
/*
 * windowFromString() : Convert a string to a Window, handling our special
 *      cases of PointerWindow, InputFocus, or ClickWindow.
 */
static Window
windowFromString(str)
char *str;
{
    Window w;

    if (strcmp(str,"PointerWindow") == 0) {
        return(PointerWindow);
    } else if (strcmp(str,"InputFocus") == 0) {
        return(InputFocus);
    } else if (strcmp(str,"ClickWindow") == 0) {
        return(Select_Window(display));
    } else if ((w=(Window)strtol(str,NULL,0)) != 0) {
       return(w);
    } else if ((w=Window_With_Name(display,root,str)) != ((Window) NULL)) {
        return(w);
    } else {
        return((Window)None);
    }
}

/*      -       -       -       -       -       -       -       -       */
/* Action procedures */

/*
 * quit() : Quit the tool.
 */
/*ARGSUSED*/
static void
quit(w,event,params,num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
    XtDestroyApplicationContext(appContext);
    exit(0);
}

/*
 * send() : With one argument, send the event sequence given by the first
 *      argument to the default window. With two arguments, the first
 *      is the window to send the event sequence given by the second to.
 * gf: With no arguments, propagate the event to the default window.
 */
/*ARGSUSED*/
static void
send(w,event,params,num_params)
Widget w;
XEvent *event;
String *params;
Cardinal *num_params;
{
    static Window defaultWin;
    char *estr,*wstr;

    if (*num_params == ZERO) {
        if (defaultWin == ((Window) NULL) &&
            (defaultWin = windowFromString(appResources.window)) == ((Window) NULL)) {
            fprintf(stderr,"xse: no arguments to xse-send() and no window\n");
            return;
        }
        event->xany.window = defaultWin;
        XSendEvent(display,defaultWin,True,0xfff,event);
        return;
    } else if (*num_params == ONE) {
        wstr = appResources.window;
        estr = params[0];
    } else if (*num_params == TWO) {
        wstr = params[0];
        estr = params[1];
    } else {
        fprintf(stderr,"xse: too many arguments to xse-send()\n");
        return;
    }
    parseAndSendEvents(windowFromString(wstr),estr);
}

/*
 * parseAndSendEvents() : Calls parseEventList() then dispatches the list
 *                        of returned events.
 */
static void
parseAndSendEvents(window,str)
Window window;
char *str;
{
    char *s;
    EventListPtr list = NULL;

    s = parseEventList(str,&list);
    if (*s != '\0') {
        printf("xse: garbage at end of event spec: \"%s\"\n",s);
        return;
    }
    while (list != NULL) {
        if (list->event.xany.type != -1) {
            list->event.xany.display = display;
            list->event.xany.window = window;
            while (list->count-- != 0)
                XSendEvent(display,window,True,0xfff,&(list->event));
        }
        list = list->next;
    }
    freeEventList(list);
}

/*      -       -       -       -       -       -       -       -       */
/*
 *      fail() : Print a message and die.
 */
static void
fail(fmt,arg)
char *fmt,*arg;
{
    fprintf(stderr,fmt,arg);
    XtDestroyApplicationContext(appContext);
    exit(1);
}

/*      -       -       -       -       -       -       -       -       */
/*      -       -       -       -       -       -       -       -       */
/* Added for window managers like swm and tvtwm that follow solbourne's
 * virtual root window concept
 */

#include <X11/Xatom.h>

static Window
GetRootWindow(disp,scrn)
Display *disp;
int scrn;
{
  Atom __SWM_VROOT = None;
  Window        root, rootReturn, parentReturn, *children;
  unsigned int  numChildren;
  int           i;

  root = RootWindow(disp, scrn);

  /* see if there is a virtual root */
  __SWM_VROOT = XInternAtom(disp, "__SWM_VROOT", False);
  XQueryTree(disp, root, &rootReturn, &parentReturn, &children, &numChildren);
  for(i = 0; i < numChildren; i++) {
    Atom actual_type;
    int actual_format;
    long nitems, bytesafter;
    Window *newRoot = (Window)0;

    if (XGetWindowProperty (disp, children[i], __SWM_VROOT,0,1,
                            False, XA_WINDOW, &actual_type, &actual_format,
                            &nitems, &bytesafter,
                            (unsigned char **) &newRoot) ==
        Success && newRoot) {
      root = *newRoot;
      break;
    }
  }
  return(root);
}

/*      -       -       -       -       -       -       -       -       */
/*      -       -       -       -       -       -       -       -       */
/*
 * [These functions are from the file "dsimple.c" used with xwininfo.]
 *
 * Written by Mark Lillibridge.   Last updated 7/1/87
 *
 * Send bugs, etc. to chariot@athena.mit.edu.
 *
 * Window_With_Name: routine to locate a window with a given name on a display.
 *                   If no window with the given name is found, 0 is returned.
 *                   If more than one window has the given name, the first
 *                   one found will be returned.  Only top and its subwindows
 *                   are looked at.  Normally, top should be the RootWindow.
 */
static Window
Window_With_Name(dpy, top, name)
     Display *dpy;
     Window top;
     char *name;
{
        Window *children, dummy;
        unsigned int nchildren;
        int i;
        Window w=0;
        char *window_name;

        if (XFetchName(dpy, top, &window_name) && !strcmp(window_name, name))
          return(top);

        if (!XQueryTree(dpy, top, &dummy, &dummy, &children, &nchildren))
          return(0);

        for (i=0; i<nchildren; i++) {
                w = Window_With_Name(dpy, children[i], name);
                if (w)
                  break;
        }
        if (children) XFree ((char *)children);
        return(w);
}

/*
 * Routine to let user select a window using the mouse
 * gf: Doesn't need "screen" defined.
 * gf: Uses global "root" rather than calling DefaultRootWindow() again,
 *     also so virtual root windows can be handled.
 */

#include <X11/cursorfont.h>

static Window
Select_Window(dpy)
      Display *dpy;
{
  static Cursor cursor = ((Cursor) NULL);
  Window target_win = None;
  XEvent event;
  int status;
  int buttons = 0;

  if (cursor == ((Cursor) NULL))
    cursor = XCreateFontCursor(dpy, XC_crosshair);
  /* Grab the pointer using target cursor, letting it room all over */
  status = XGrabPointer(dpy, root, False,
                        ButtonPressMask|ButtonReleaseMask, GrabModeSync,
                        GrabModeAsync, root, cursor, CurrentTime);
  if (status != GrabSuccess) {
    fprintf(stderr,"xse: can't grab pointer");
    return(None);
  }
  /* Let the user select a window... */
  while ((target_win == None) || (buttons != 0)) {
    /* allow one more event */
    XAllowEvents(dpy, SyncPointer, CurrentTime);
    XWindowEvent(dpy, root, ButtonPressMask|ButtonReleaseMask, &event);
    switch (event.type) {
    case ButtonPress:
      if (target_win == None) {
        target_win = event.xbutton.subwindow; /* window selected */
        if (target_win == None) target_win = root;
      }
      buttons++;
      break;
    case ButtonRelease:
      if (buttons > 0) /* there may have been some down before we started */
        buttons--;
       break;
    }
  }
  XUngrabPointer(dpy, CurrentTime);      /* Done with pointer */
  return(target_win);
}
