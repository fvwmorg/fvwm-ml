/*
 * patchlevel.h : Version control
 *
 * Richard A. Guay, rag@asicint.com
 *
 */

#define FVWM_XSE_MAJOR_VERSION  2
#define FVWM_XSE_MINOR_VERSION  0
#define FVWM_XSE_EXTRA_VERSION  ""
